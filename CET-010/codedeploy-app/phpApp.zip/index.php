<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>AWS RSA Training  CET009 CodeDeploy </title>
  <style>
    body {
      
      background-image: url('https://www.rackspace.com/themes/custom/rackspace/libraries/zoolander2/dist/imgs/derek/banners/homepage-banner-1280.jpg');
      font-family: Arial, sans-serif;
      font-size: 14px;
    }
    
    h1 {
      font-size: 500%;
      font-weight: normal;
      margin-bottom: 0;
      
    }
    
    h2 {
      font-size: 200%;
      font-weight: normal;
      margin-bottom: 0;
    }
  </style>
</head>
<body>
  <div align="center">
  
    <?php
      echo "<h1>" . "AWS Training  " ."</h1>";
      echo "<h2>" ."Task_NO:". "CET-009". "CodeDeploy lab" . "</h2>";
      echo "Today is " . date("Y/m/d") . "<br>";
      echo "Today is " . date("Y.m.d") . "<br>";
      echo "Today is " . date("Y-m-d") . "<br>";
      echo "Today is " . date("l");
  ?>

  </div>
</body>
</html>
